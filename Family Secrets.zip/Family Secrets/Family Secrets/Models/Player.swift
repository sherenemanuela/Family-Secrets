//
//  Player.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import Foundation

class Player {
    var id: String
    var cardDeck: Array<GameCard> = []
    
    init(id: String) {
        self.id = id
    }
    
    func initializeDeck(gameDeck: Array<GameCard>) {
        cardDeck.append(CardGenerator.GetRandomCardOfCertainType(type: "truth", gameDeck: gameDeck))
        cardDeck.append(CardGenerator.GetRandomCardOfCertainType(type: "dare", gameDeck: gameDeck))
        cardDeck.append(CardGenerator.GetRandomCardOfCertainType(type: "ask", gameDeck: gameDeck))
        cardDeck.append(CardGenerator.GetRandomCard(gameDeck: gameDeck))
        cardDeck.append(CardGenerator.GetRandomCard(gameDeck: gameDeck))
    }
    
    func removeCard(index: Int) {
        cardDeck.remove(at: index)
    }
}
