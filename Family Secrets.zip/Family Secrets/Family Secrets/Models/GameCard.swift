//
//  Card.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import Foundation

class GameCard {
    var id: Int
    var type: String
    var filename: String
    var gameMode: String
    var prompt: String
    var isInPlayerDeck: Bool = false
    var nextType: Array<String>
    
    init(id: Int, type: String, filename: String, gameMode: String, prompt: String, nextType: Array<String>) {
        self.id = id
        self.type = type
        self.filename = filename
        self.gameMode = gameMode
        self.prompt = prompt
        self.nextType = nextType
    }
}
