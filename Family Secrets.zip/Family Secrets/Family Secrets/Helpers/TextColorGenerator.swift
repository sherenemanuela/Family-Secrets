//
//  TextColorGenerator.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 04/05/23.
//

import Foundation

class TextColorGenerator {
    
    let text: String
    
    func 
}
