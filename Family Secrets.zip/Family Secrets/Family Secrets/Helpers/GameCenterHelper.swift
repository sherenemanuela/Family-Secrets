//
//  GameCenterHelper.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 24/04/23.
//

import Foundation
import GameKit

class GameCenterHelper: NSObject, GKLocalPlayerListener {
    
    var match: GKMatch?
//    var otherPlayer: GKPlayer
//    var localPlayer = GKLocalPlayer.local
//    
//    var playerUUIDKey = UUID().uuidString
    
    var rootViewController: UIViewController? {
        let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene
        return windowScene?.windows.first?.rootViewController
    }
    
    func AuthenticateUser() {
        GKLocalPlayer.local.authenticateHandler = { viewController, error in
            
            if GKLocalPlayer.local.isAuthenticated {
                print("Authenticated to Game Center!")
            } else if let vc = viewController {
                viewController?.present(vc, animated: true)
            }
            else {
                print("Error authentication to GameCenter: " +
                      "\(error?.localizedDescription ?? "none")")
            }
        }
    }
    
    func StartMatchmaking() {
        let request = GKMatchRequest()
        request.minPlayers = 2
        request.maxPlayers = 2
        request.inviteMessage = "Let's play Family Secrets together!"
        
        let matchmakingViewController = GKMatchmakerViewController(matchRequest: request)
        matchmakingViewController?.matchmakerDelegate = self
        
        rootViewController?.present(matchmakingViewController! , animated: true)
    }
    
    func StartGame(newMatch: GKMatch) {
        match = newMatch
        match?.delegate = self
    }
}

extension GameCenterHelper: GKMatchmakerViewControllerDelegate {
    func matchmakerViewControllerWasCancelled(_ viewController: GKMatchmakerViewController) {
        viewController.dismiss(animated: true)
    }
    
    func matchmakerViewController(_ viewController: GKMatchmakerViewController, didFailWithError error: Error) {
        viewController.dismiss(animated: true)
        print("Matchmaker vc did fail with error: \(error.localizedDescription).")
    }
    
    func matchmakerViewController(_ viewController: GKMatchmakerViewController, didFind match: GKMatch) {
        viewController.dismiss(animated: true)
        StartGame(newMatch: match)
    }
}

extension GameCenterHelper: GKMatchDelegate {
    func match(_ match: GKMatch, didReceive data: Data, fromRemotePlayer player: GKPlayer) {
         
    }
}
