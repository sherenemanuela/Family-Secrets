//
//  CardGenerator.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import Foundation

final class CardGenerator {
    
    static let TruthCards = [
        ["TruthCard", "Truth"],
        ["TruthCard", "Truth"]
    ]
    
    static let DareCards = [
        ["DareCard", "Dare", "online"],
        ["DareCard", "Dare", "offline"]
    ]
    
    static let AskCards = [
        ["AskCard", "Ask"],
        ["AskCard", "Ask"]
    ]
    
    static let SpecialCards = [
        ["SpecialFreeCard", "Free"],
        ["Special1Card", "1"],
        ["Special2Card", "2"],
        ["Special3Card", "3"]
    ]
    
    static func InitializeGameDeck() -> Array<GameCard> {
        var id = 0
        var deck: Array<GameCard> = []
        
        for card in TruthCards {
            deck.append(GameCard(id: id, type: "truth", filename: card[0], gameMode: "Online", prompt: card[1]))
            id += 1
        }
        
        for card in DareCards {
            deck.append(GameCard(id: id, type: "dare", filename: card[0], gameMode: card[2], prompt: card[1]))
            id += 1
        }
        
        for card in AskCards {
            deck.append(GameCard(id: id, type: "ask", filename: card[0], gameMode: "Online", prompt: card[1]))
            id += 1
        }
        
        for card in SpecialCards {
            deck.append(GameCard(id: id, type: "special", filename: card[0], gameMode: "Online", prompt: card[1]))
            id += 1
        }
        
        return deck.shuffled()
    }
    
    static func GetRandomCardOfCertainType(type: String, gameDeck: Array<GameCard>) -> GameCard {
        let randomTruthCard = gameDeck.first {
            $0.type == type && $0.isInPlayerDeck == false
        }
        randomTruthCard!.isInPlayerDeck = true
        return randomTruthCard!
    }
    
    static func GetRandomCard(gameDeck: Array<GameCard>) -> GameCard {
        let randomCard = gameDeck.first {
            $0.isInPlayerDeck == false
        }
        randomCard!.isInPlayerDeck = true
        return randomCard!
    }
}
