//
//  CardGenerator.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import Foundation

final class CardGenerator {
    
    static let TruthCards = [
        // filename, prompt, nextType
        ["TruthCard", "Truth", ["dare", "ask", "special"]] as [Any],
        ["TruthCard", "Truth", ["dare", "ask", "special"]],
        ["TruthCard", "Truth", ["dare", "ask", "special"]],
        ["TruthCard", "Truth", ["dare", "ask", "special"]],
        ["TruthCard", "Truth", ["dare", "ask", "special"]],
        ["TruthCard", "Truth", ["dare", "ask", "special"]],
        ["TruthCard", "Truth", ["dare", "ask", "special"]],
        ["TruthCard", "Truth", ["dare", "ask", "special"]]
    ]
    
    static let DareCards = [
        // filename, prompt, gamemode, nextType
        ["DareCard", "Dare", "Online", ["truth", "ask", "special"]] as [Any],
        ["DareCard", "Dare", "Offline", ["truth", "ask", "special"]],
        ["DareCard", "Dare", "Offline", ["truth", "ask", "special"]],
        ["DareCard", "Dare", "Offline", ["truth", "ask", "special"]],
        ["DareCard", "Dare", "Offline", ["truth", "ask", "special"]],
        ["DareCard", "Dare", "Offline", ["truth", "ask", "special"]]
    ]
    
    static let AskCards = [
        // filename, prompt, nextType
        ["AskCard", "Ask", ["truth", "dare", "special"]] as [Any],
        ["AskCard", "Ask", ["truth", "dare", "special"]],
        ["AskCard", "Ask", ["truth", "dare", "special"]],
        ["AskCard", "Ask", ["truth", "dare", "special"]],
        ["AskCard", "Ask", ["truth", "dare", "special"]],
        ["AskCard", "Ask", ["truth", "dare", "special"]],
        ["AskCard", "Ask", ["truth", "dare", "special"]]
    ]
    
    static let SpecialCards = [
        // filename, prompt
        ["SpecialFreeCard", "free"],
        ["Special1Card", "1"],
        ["Special2Card", "2"],
        ["Special3Card", "3"],
        ["Special2Card", "4"],
    ]
    
    static func InitializeGameDeck() -> Array<GameCard> {
        var id = 0
        var deck: Array<GameCard> = []
        
        for card in TruthCards {
            deck.append(GameCard(id: id, type: "truth", filename: card[0] as! String, gameMode: "Online", prompt: card[1] as! String, isInPlayerDeck: false, nextType: card[2] as! Array<String>) )
            id += 1
        }
        
        for card in DareCards {
            deck.append(GameCard(id: id, type: "dare", filename: card[0] as! String, gameMode: card[2] as! String, prompt: card[1] as! String, isInPlayerDeck: false, nextType: card[3] as! Array<String>))
            id += 1
        }
        
        for card in AskCards {
            deck.append(GameCard(id: id, type: "ask", filename: card[0] as! String, gameMode: "Online", prompt: card[1] as! String, isInPlayerDeck: false, nextType: card[2] as! Array<String>))
            id += 1
        }
        
        for card in SpecialCards {
            deck.append(GameCard(id: id, type: "special", filename: card[0], gameMode: "Online", prompt: card[1], isInPlayerDeck: false, nextType: ["truth", "dare", "ask", "special"]))
            id += 1
        }
        
        return deck.shuffled()
    }
    
    static func GetRandomCardOfCertainType(type: String, gameDeck: Array<GameCard>) -> GameCard {
        let randomTruthCard = gameDeck.first {
            $0.type == type && $0.isInPlayerDeck == false
        }
        randomTruthCard!.isInPlayerDeck = true
        return randomTruthCard!
    }
    
    static func GetRandomCard(gameDeck: Array<GameCard>) -> GameCard {
        let randomCard = gameDeck.first {
            $0.isInPlayerDeck == false
        }
        randomCard!.isInPlayerDeck = true
        return randomCard!
    }
}
