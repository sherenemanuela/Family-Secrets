//
//  OnlineGameViewModel.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 26/04/23.
//

import Foundation

class OnlineGameViewModel: ObservableObject {
    
    
}
