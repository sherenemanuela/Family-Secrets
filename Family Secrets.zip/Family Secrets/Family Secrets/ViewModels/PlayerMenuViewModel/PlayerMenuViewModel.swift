//
//  PlayerMenuViewModel.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 26/04/23.
//

import Foundation

class PlayerMenuViewModel: ObservableObject {
    
    @Published var selectedPlayerCount: Int = 2
    @Published var navigateToOnlineGameView: Bool = false
    @Published var navigateToOfflineGameView: Bool = false
    
    func OnlineGameView() {
        navigateToOnlineGameView = true
    }
    
    func OfflineGameView() {
        navigateToOfflineGameView = true
    }
}

extension PlayerMenuView {
    func SavePlayerCount() {
        let newGame: Game
        
        if game.isEmpty {
            newGame = Game(context: managedObjectContext)
        } else {
            newGame = game.first!
        }
        
        newGame.playerCount = Int16(viewModel.selectedPlayerCount)
        
        do {
            try managedObjectContext.save()
            print("Saved")
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
        
        if game.first!.gameMode! == "Online" {
            viewModel.OnlineGameView()
        } else {
            // offline game view
        }
    }
}
