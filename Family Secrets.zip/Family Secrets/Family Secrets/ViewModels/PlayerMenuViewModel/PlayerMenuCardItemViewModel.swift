//
//  PlayerMenuCardViewModel.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 25/04/23.
//

import Foundation
import SwiftUI

class PlayerMenuCardItemViewModel: ObservableObject {
    
    @Published var width: Double = 0
    @Published var height: Double = 0
    @Published var fontSize: Double = 0
    @Published var cornerRadius: Double = 0
    @Published var overlayOpacity: Double = 0
    @Published var shadowRadius: Double = 0
    @Published var shadowX: Double = 0
    @Published var shadowY: Double = 0
    @Published var buttonOpacity: Double = 0
    @Published var textOffset: CGSize = CGSizeZero
    @Published var imageSize: Double = 0
    
    func SetAppropriateAttribute(selectedPlayerCount: Int, playerCount: Int) {
        if selectedPlayerCount != playerCount {
            width = 120
            height = 170
            cornerRadius = 5
            fontSize = 15
            overlayOpacity = 0.2
            shadowX = 2
            shadowY = 4
            shadowRadius = 2
            buttonOpacity = 0
            textOffset = CGSize(width: 0, height: 0)
            imageSize = 30
        } else {
            width = 140
            height = 190
            cornerRadius = 5
            fontSize = 20
            overlayOpacity = 0
            shadowX = 5
            shadowY = 8
            shadowRadius = 5
            buttonOpacity = 1
            textOffset = CGSizeZero
            imageSize = 40
        }
    }
}
