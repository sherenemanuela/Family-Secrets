//
//  SplashViewModel.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 24/04/23.
//

import Foundation
import SwiftUI
import GameKit
import UIKit

class SplashViewModel: ObservableObject {
    
    @Published internal var authenticateButtonOpacity: Double = 0
    
    func ShowLoginButtons() {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3 ) {
            self.authenticateButtonOpacity = 1
        }
    }
    
    func UserLogin() {
        GameCenterHelper().AuthenticateUser()
    }
    
    func GuestLogin() {
//        ProfileView()
    }
}
