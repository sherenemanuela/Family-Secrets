//
//  DataExchange.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 29/04/23.
//

import Foundation
import GameKit

extension OnlineGameViewModel: GKMatchDelegate {
    
    func match(_ match: GKMatch, player: GKPlayer, didChange state: GKPlayerConnectionState) {
        print("ADA YG DISCONNECT")
    }
    
    func match(_ match: GKMatch, didFailWithError error: Error?) {
        print("MATCH INVALID")
    }
    
    func match(_ match: GKMatch, didReceive data: Data, fromRemotePlayer player: GKPlayer) {
//        print("ADA DATA MASUK DARI \(player.displayName)")
        DecodeReceivedData(data: data)
//        print("DECODING BERHASIL")
    }
    
    func GetCardData(label: String, card: GameCard) -> Data {
        let archiver = NSKeyedArchiver(requiringSecureCoding: false)
        archiver.encode(label, forKey: "label")
        archiver.encode(card, forKey: "data")
        return archiver.encodedData
    }
    
    func GetStringData(label: String, message: String) -> Data {
        let archiver = NSKeyedArchiver(requiringSecureCoding: false)
        archiver.encode(label, forKey: "label")
        archiver.encode(message, forKey: "data")
        return archiver.encodedData
    }
    
    func GetGameDeckData(index: Int) -> Data {
        let archiver = NSKeyedArchiver(requiringSecureCoding: true)
        archiver.encode("gameDeck", forKey: "label")
        archiver.encode(gameDeck[index], forKey: "data")
        archiver.finishEncoding()
        return archiver.encodedData
    }
    
    func GetPlayedDeckData() -> Data {
        let archiver = NSKeyedArchiver(requiringSecureCoding: false)
        archiver.encode("playedDeck", forKey: "label")
        archiver.encode(playedDeck, forKey: "data")
        return archiver.encodedData
    }
    
    func GetPlayerDeckData(index: Int) -> Data {
        let archiver = NSKeyedArchiver(requiringSecureCoding: false)
        archiver.encode("playerDeck", forKey: "label")
        archiver.encode(index, forKey: "uuid")
        archiver.encode(players[index].cardDeck, forKey: "data")
        return archiver.encodedData
    }
    
    func sendData(data: Data, mode: GKMatch.SendDataMode) {
        do {
            try match?.sendData(toAllPlayers: data, with: mode)
        } catch {
            print(error)
        }
    }
    
    func DecodeReceivedData(data: Data) {
        let unarchiver = try! NSKeyedUnarchiver(forReadingFrom: data)
        let label = unarchiver.decodeObject(forKey: "label") as! String
        
        switch label {
            
        case "playedCard":
            let data = unarchiver.decodeObject(forKey: "data") as! GameCard
            AppendPlayedDeck(playedCard: data)
            
        case "gameDeck":
            let data = unarchiver.decodeObject(of: GameCard.self, forKey: "data")!
            unarchiver.finishDecoding()
            UpdateGameDeck(card: data)
            
        case "playedDeck":
            let data = unarchiver.decodeObject(forKey: "data") as! Array<GameCard>
            UpdatePlayedDeck(newDeck: data)
            
        case "playerDeck":
            let data = unarchiver.decodeObject(forKey: "data") as! Array<GameCard>
            let id = unarchiver.decodeObject(forKey: "id") as! String
            
            for player in players {
                if player.id == id {
                    player.cardDeck = data
                }
            }
            
        default:
            let data = unarchiver.decodeObject(forKey: "data") as! String
            
            if label == "currentPlayer" {
                currentPlayer = data
            } else {
                print("INI DATA UUID")
                AppendPlayers(playerId: data)
                
                if players.count == playerCount {
                    InitGameRoom()
                }
            }
            
        }
        unarchiver.finishDecoding()
    }
}
