//
//  GameCardViewModel.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import Foundation
import SwiftUI

class GameCardViewModel: ObservableObject {
    
    @Published var width: Double = 80
    @Published var height: Double = 120
    @Published var offset: CGSize
    
    init(offset: CGSize) {
        self.offset = offset
    }
    
    func tapped() {
        if offset.height == 0 {
            offset = CGSize(width: 0, height: -20)
        } else {
            offset = CGSizeZero
        }
    }
}
