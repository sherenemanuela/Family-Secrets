//
//  GameCardViewModel.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import Foundation
import SwiftUI

class GameCardViewModel: ObservableObject {

    
}
