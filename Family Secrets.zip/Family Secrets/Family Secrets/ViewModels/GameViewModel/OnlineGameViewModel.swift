//
//  GameCenterHelper.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 24/04/23.
//

import Foundation
import GameKit

class OnlineGameViewModel: NSObject, GKLocalPlayerListener, ObservableObject {
    
    @Published var players: Array<Player> = []
    @Published var matchFound = false
    @Published var playedDeck: Array<GameCard> = []
    @Published var gameDeck: Array<GameCard> = []
    @Published var currentPlayer: String = "1"
    
    var playerCount: Int = 4
    
    var match: GKMatch?
//    var localPlayer = GKLocalPlayer.local
//    var playerUUIDKey = UUID().uuidString
//
//    func StartGame(newMatch: GKMatch) {
//        match = newMatch
//        match?.delegate = self
//
//    }
    
    func InitGameRoom() {
//        for i in (0 ... playerCount) {
//            let id = i
//            players.append(Player(id: String(id), gameDeck: gameDeck))
//        }
        
        gameDeck = CardGenerator.InitializeGameDeck()
        players.append(Player(id: "1", gameDeck: gameDeck))
        playedDeck.append(CardGenerator.GetRandomCard(gameDeck: gameDeck))
    }
    
    func AddToPlayedDeck(index: Int) {
        playedDeck.append(players[0].cardDeck[index])
            players[0].cardDeck.remove(at: index)
            print("udah")
//            RefreshDeck()
    }
    
    func RefreshDeck() {
        objectWillChange.send()
    }
    
    func CheckForWinner() -> String {
        for player in players {
            if player.cardDeck.count == 0 {
                return player.id
            }
        }
        return "none"
    }
    
    func IsAllowedToTakeCard() -> Bool {
        if currentPlayer == players[0].id {
            return true
        }
        return false
    }
    
    func CardChosenisValidAnswer(index: Int) -> Bool {
        let topmost = playedDeck.last
        let card = players[0].cardDeck[index]
        
        for type in topmost!.nextType {
            if type == card.type {
                return true
            }
        }
        return false
    }
    
    func CheckGameDeck() {
        if gameDeck.isEmpty {
            for card in playedDeck {
                // kalo error nnti coba truncate aja smua except last card
                if card.isInPlayerDeck == false && card.id != playedDeck.last!.id {
                    gameDeck.append(card)
                    playedDeck.removeFirst()
                }
            }
            gameDeck.shuffle()
        }
    }
}


extension OnlineGameViewModel {
    var rootViewController: UIViewController? {
        let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene
        return windowScene?.windows.first?.rootViewController
    }
    
    func StartMatchmaking() {
        let request = GKMatchRequest()
        request.minPlayers = playerCount
        request.maxPlayers = playerCount
        request.inviteMessage = "Let's play Family Secrets together!"
        
        let matchmakingViewController = GKMatchmakerViewController(matchRequest: request)
        matchmakingViewController?.matchmakerDelegate = self
        
        rootViewController?.present(matchmakingViewController! , animated: true)
    }
}
