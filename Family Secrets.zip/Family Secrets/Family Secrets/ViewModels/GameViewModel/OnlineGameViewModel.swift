//
//  GameCenterHelper.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 24/04/23.
//

import Foundation
import GameKit

class OnlineGameViewModel: NSObject, GKLocalPlayerListener, ObservableObject {
    
    let otherCardWidth: Double = 50
    let otherCardHeight: Double = 90
    let cardWidth: Double = 100
    let cardHeight: Double = 140
    @Published var players: Array<Player> = []
    @Published var matchFound = false
    
    let gameDeck: Array<GameCard> = CardGenerator.InitializeGameDeck()
    var playerCount: Int = 4
    
    var match: GKMatch?
//    var localPlayer = GKLocalPlayer.local
//    var playerUUIDKey = UUID().uuidString
    
    func StartGame(newMatch: GKMatch) {
        match = newMatch
        match?.delegate = self
        
    }
    
    func InitPlayers() {
//        for i in (0 ... playerCount) {
//            let id = i
//            players.append(Player(id: String(id), gameDeck: gameDeck))
//        }
        players.append(Player(id: "1", gameDeck: gameDeck))
        print(players[0].cardDeck)
    }
}


extension OnlineGameViewModel {
    var rootViewController: UIViewController? {
        let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene
        return windowScene?.windows.first?.rootViewController
    }
    
    func StartMatchmaking() {
        let request = GKMatchRequest()
        request.minPlayers = playerCount
        request.maxPlayers = playerCount
        request.inviteMessage = "Let's play Family Secrets together!"
        
        let matchmakingViewController = GKMatchmakerViewController(matchRequest: request)
        matchmakingViewController?.matchmakerDelegate = self
        
        rootViewController?.present(matchmakingViewController! , animated: true)
    }
}
