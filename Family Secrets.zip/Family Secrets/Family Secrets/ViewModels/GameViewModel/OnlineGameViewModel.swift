//
//  GameCenterHelper.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 24/04/23.
//

import Foundation
import GameKit

class OnlineGameViewModel: NSObject, GKLocalPlayerListener, ObservableObject {
    
    @Published var players: Array<Player> = []
    @Published var matchFound = false
    @Published var playedDeck: Array<GameCard> = []
    @Published var gameDeck: Array<GameCard> = []
    @Published var currentPlayer: String = ""
    
    var playerCount: Int = 2
    var match: GKMatch?
    
    func InitGameRoom() {
        var firstPlayerId = players[0].id
        
        for player in players {
            if player.id < firstPlayerId {
                firstPlayerId = player.id
            }
        }
        
        print("INITIALIZE GAME ROOM")
        print("LOCAL \(players[0].id)")
        print("REMOTE \(players[1].id)")
        print("YANG PERTAMA \(firstPlayerId)")
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3) { [self] in
            if players[0].id == firstPlayerId {
                InitGameData()
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3) {
                    self.SendGameData()
                }
            }
        }
    }
    
    func SendGameData() {
        for index in 0 ..< gameDeck.count {
            sendData(data: GetGameDeckData(index: index), mode: .reliable)
        }
        print("DATA SENT!")
//        sendData(data: GetPlayedDeckData(), mode: .reliable)
//        sendData(data: GetStringData(label: "currentPlayer", message: currentPlayer), mode: .reliable)
//        
//        for index in 1 ..< playerCount {
//            sendData(data: GetPlayerDeckData(index: index), mode: .reliable)
//        }
    }
    
    func InitGameData() {
        gameDeck = CardGenerator.InitializeGameDeck()
        playedDeck.append(CardGenerator.GetRandomCard(gameDeck: gameDeck))
        currentPlayer = players[0].id

        for player in players {
            player.initializeDeck(gameDeck: gameDeck)
        }
    }
    
    func AddToPlayedDeck(index: Int) {
        playedDeck.append(players[0].cardDeck[index])
        players[0].cardDeck.remove(at: index)
    }
    
    func RefreshDeck() {
        objectWillChange.send()
    }
    
    func StartGame(newMatch: GKMatch) {
        print("MATCH KETEMU")
        match = newMatch
        match?.delegate = self
        sendData(data: GetStringData(label: "uuid", message: players[0].id), mode: .reliable)
        print("DATA USER UDAH DIKIRIM")
    }
    
    func UpdateGameDeck(card: GameCard) {
        gameDeck.append(card)
    }
    
    func UpdatePlayedDeck(newDeck: Array<GameCard>) {
        playedDeck = newDeck
    }
    
    func AppendPlayedDeck(playedCard: GameCard) {
        playedDeck.append(playedCard)
    }
    
    func AppendPlayers(playerId: String) {
        players.append(Player(id: playerId))
    }
}
