//
//  CoreDataStack.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 25/04/23.
//

import Foundation
import CoreData

class CoreDataStack {
    
}
