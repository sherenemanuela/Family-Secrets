//
//  PlayerMenuView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 25/04/23.
//

import SwiftUI

struct PlayerMenuView: View {
    
    @Environment(\.managedObjectContext) var managedObjectContext
    @FetchRequest(entity: Game.entity(), sortDescriptors: []) var game: FetchedResults<Game>
    @StateObject var viewModel = PlayerMenuViewModel()
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color("DarkBlue")
                
                VStack {
                    Text("How many people are playing?")
                        .foregroundColor(.white)
                        .font(.system(size: 25))
                        .bold()
                    
                    PlayerMenuCardSelectionView(selectedPlayerCount: $viewModel.selectedPlayerCount)
                    
                    Button() {
                        SavePlayerCount()
                    } label: {
                        HStack {
                            Image(systemName: "play.fill")
                            Text("Next")
                                .font(.system(size: 20))
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .offset(CGSize(width: 320, height: 20))
                    .padding(.top, -20)
                }
                .frame(height: 300)
            }
            .ignoresSafeArea()
            .navigationDestination(isPresented: $viewModel.navigateToOnlineGameView) {
                OnlineGameView()
            }
        }
    }
}

struct PlayerMenuView_Previews: PreviewProvider {
    static var previews: some View {
        PlayerMenuView()
            .previewInterfaceOrientation(.landscapeRight)
    }
}
