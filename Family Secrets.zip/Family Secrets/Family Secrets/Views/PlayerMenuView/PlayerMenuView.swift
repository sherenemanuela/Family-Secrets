//
//  PlayerMenuView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 25/04/23.
//

import SwiftUI

struct PlayerMenuView: View {
    var body: some View {
        ZStack {
            Color("DarkBlue")
            
            VStack {
                Text("How many people are playing?")
                    .foregroundColor(.white)
                    .font(.system(size: 25))
                    .bold()
                
                PlayerMenuCardSelectionView()
                
                Button() {
                } label: {
                    HStack {
                        Image(systemName: "play.fill")
                        Text("Next")
                            .font(.system(size: 20))
                    }
                }
                .buttonStyle(.borderedProminent)
                .offset(CGSize(width: 320, height: 20))
                .padding(.top, -20)
            }
            .frame(height: 300)
        }
        .ignoresSafeArea()
    }
}

struct PlayerMenuView_Previews: PreviewProvider {
    static var previews: some View {
        PlayerMenuView()
            .previewInterfaceOrientation(.landscapeRight)
    }
}
