//
//  PlayerMenuCardItemView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 25/04/23.
//

import SwiftUI

struct PlayerMenuCardItemView: View {
    
    let playerCount: Int
    @Binding var selectedPlayerCount: Int
    @StateObject var viewModel = PlayerMenuCardItemViewModel()
    
    var body: some View {
        ZStack {
            Rectangle()
                .fill(.white)
                .frame(width: viewModel.width, height: viewModel.height)
                .cornerRadius(viewModel.cornerRadius)
                .shadow(color: .black, radius: viewModel.shadowRadius, x: viewModel.shadowX, y: viewModel.shadowY)
            
            Rectangle()
                .fill(.yellow)
                .frame(width: viewModel.width - 20, height: viewModel.height - 20)
                .cornerRadius(viewModel.cornerRadius - 2)
            
            Rectangle()
                .fill(.white)
                .frame(width: viewModel.width - 35, height: viewModel.height - 35)
                .cornerRadius(viewModel.cornerRadius - 4)
            
            Rectangle()
                .fill(.black)
                .frame(width: viewModel.width, height: viewModel.height)
                .cornerRadius(viewModel.cornerRadius)
                .opacity(viewModel.overlayOpacity)
            
            VStack {
                Circle()
                    .frame(width: viewModel.imageSize)
                
                Text("\(playerCount) Players")
                    .font(.system(size: viewModel.fontSize))
                    .bold()
                    .offset(viewModel.textOffset)
                    .padding(.top, 20)
            }
        }
        .onTapGesture {
            selectedPlayerCount = playerCount
        }
        .onAppear() {
            viewModel.SetAppropriateAttribute(selectedPlayerCount: selectedPlayerCount, playerCount: playerCount)
        }
        .onChange(of: selectedPlayerCount) { _ in
            viewModel.SetAppropriateAttribute(selectedPlayerCount: selectedPlayerCount, playerCount: playerCount)
        }
    }
    
}

struct PlayerMenuCardItemView_Previews: PreviewProvider {
    static var previews: some View {
        PlayerMenuCardItemView(playerCount: 1, selectedPlayerCount: .constant(1))
            .previewInterfaceOrientation(.landscapeRight)
    }
}
