//
//  PlayerMenuCardSelectionView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 25/04/23.
//

import SwiftUI

struct PlayerMenuCardSelectionView: View {
    
    @Binding var selectedPlayerCount: Int
    
    var body: some View {
        ZStack {
            Color("DarkBlue")
            
            HStack(spacing: 50) {
                PlayerMenuCardItemView(playerCount: 2, selectedPlayerCount: $selectedPlayerCount)
                
                PlayerMenuCardItemView(playerCount: 3, selectedPlayerCount: $selectedPlayerCount)
                
                PlayerMenuCardItemView(playerCount: 4, selectedPlayerCount: $selectedPlayerCount)
            }
        }
        .ignoresSafeArea()
    }
}

struct PlayerMenuCardSelectionView_Previews: PreviewProvider {
    static var previews: some View {
        PlayerMenuCardSelectionView(selectedPlayerCount: .constant(2))
            .previewInterfaceOrientation(.landscapeRight)
    }
}
