//
//  SplashView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 24/04/23.
//

import SwiftUI

struct SplashView: View {
    
    @StateObject private var viewModel = SplashViewModel()
    
    var body: some View {
        ZStack {
            Image("SplashBackground")
                .resizable()
            
            VStack {
                Button("Sign In", action: viewModel.UserLogin)
                    .buttonStyle(.borderedProminent)
                    .foregroundColor(.black)
                
                Button("Continue as Guest", action: viewModel.GuestLogin)
            }
            .offset(CGSize(width: 0, height: 150))
            .opacity(viewModel.authenticateButtonOpacity)
            .tint(.white)
        }
        .ignoresSafeArea()
        .onAppear() {
            viewModel.ShowLoginButtons()
        }
    }
}

struct SplashView_Previews: PreviewProvider {
    static var previews: some View {
        SplashView() .previewInterfaceOrientation(.landscapeRight)
    }
}
