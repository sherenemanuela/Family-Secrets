//
//  CardMenuView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 25/04/23.
//

import SwiftUI

struct GameMenuCardSelectionView: View {
    
    @Environment(\.managedObjectContext) var managedObjectContext
    @FetchRequest(entity: Game.entity(), sortDescriptors: []) var game: FetchedResults<Game>
    @StateObject var viewModel = GameMenuCardSelectionViewModel()
    
    var body: some View {
        NavigationStack {
            ZStack {
                
                HStack(spacing: 10) {
                    GameMenuCardItemView(gameMode: "Online", selectedMode: $viewModel.selectedMode, navigateToPlayerMenuView: $viewModel.navigateToPlayerMenuView)
                    
                    GameMenuCardItemView(gameMode: "Offline", selectedMode: $viewModel.selectedMode, navigateToPlayerMenuView: $viewModel.navigateToPlayerMenuView).onTapGesture {
                        if viewModel.selectedMode == "Offline" {
                            viewModel.PlayerMenuView()
                        }
                    }
                }
            }
            .ignoresSafeArea()
            .onChange(of: viewModel.navigateToPlayerMenuView) { _ in
                SaveGameMode()
            }
            .navigationDestination(isPresented: $viewModel.navigateToPlayerMenuView) {
                PlayerMenuView()
                    .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
            }
        }
    }
}

struct GameMenuCardSelectionView_Previews: PreviewProvider {
    static var previews: some View {
        GameMenuCardSelectionView()
            .previewInterfaceOrientation(.landscapeRight)
    }
}
