//
//  CardMenuView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 25/04/23.
//

import SwiftUI

struct GameMenuCardSelectionView: View {
    
    @Environment(\.managedObjectContext) var managedObjectContext
    @FetchRequest(entity: Game.entity(), sortDescriptors: []) var game: FetchedResults<Game>
    @StateObject var viewModel = GameMenuCardSelectionViewModel()
    
    var body: some View {
        ZStack {
            HStack(spacing: 50) {
                GameMenuCardItemView(gameMode: "Online", selectedMode: $viewModel.selectedMode, navigateToPlayerMenuView: $viewModel.navigateToPlayerMenuView)
                
                GameMenuCardItemView(gameMode: "Offline", selectedMode: $viewModel.selectedMode, navigateToPlayerMenuView: $viewModel.navigateToPlayerMenuView)
            }
        }
        .ignoresSafeArea()
        .onChange(of: viewModel.navigateToPlayerMenuView) { _ in
            SaveGameMode()
            print(game.first!.gameMode!)
        }
    }
}

struct GameMenuCardSelectionView_Previews: PreviewProvider {
    static var previews: some View {
        GameMenuCardSelectionView()
            .previewInterfaceOrientation(.landscapeRight)
    }
}
