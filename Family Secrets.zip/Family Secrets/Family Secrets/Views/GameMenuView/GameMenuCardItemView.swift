//
//  CardSelectionView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 25/04/23.
//

import SwiftUI

struct GameMenuCardItemView: View {
    
    let gameMode: String
    @Binding var selectedMode: String
    @Binding var navigateToPlayerMenuView: Bool
    @StateObject var viewModel = GameMenuCardItemViewModel()
    
    var body: some View {
        ZStack {
            Rectangle()
                .fill(.white)
                .frame(width: viewModel.width, height: viewModel.height)
                .cornerRadius(viewModel.cornerRadius)
                .shadow(color: .black, radius: viewModel.shadowRadius, x: viewModel.shadowX, y: viewModel.shadowY)
            
            Rectangle()
                .fill(.yellow)
                .frame(width: viewModel.width - 20, height: viewModel.height - 20)
                .cornerRadius(viewModel.cornerRadius - 2)
            
            Rectangle()
                .fill(.white)
                .frame(width: viewModel.width - 35, height: viewModel.height - 35)
                .cornerRadius(viewModel.cornerRadius - 4)
            
            Rectangle()
                .fill(.black)
                .frame(width: viewModel.width, height: viewModel.height)
                .cornerRadius(viewModel.cornerRadius)
                .opacity(viewModel.overlayOpacity)
            
            VStack {
                Text("Play \(gameMode)")
                    .font(.system(size: viewModel.fontSize))
                    .bold()
                    .offset(viewModel.textOffset)
                
                Button() {
                    PlayerMenu()
                } label: {
                    Text("Start")
                        .font(.system(size: viewModel.fontSize))
                }
                .padding(.top, 20)
                .opacity(viewModel.buttonOpacity)
            }
        }
        .onTapGesture {
            selectedMode = gameMode
        }
        .onAppear() {
            viewModel.SetAppropriateAttribute(selectedMode: selectedMode, gameMode: gameMode)
        }
        .onChange(of: selectedMode) { _ in
            viewModel.SetAppropriateAttribute(selectedMode: selectedMode, gameMode: gameMode)
        }
    }
}

struct GameMenuCardItemView_Previews: PreviewProvider {
    static var previews: some View {
        GameMenuCardItemView(gameMode: "Online", selectedMode: .constant("Online"), navigateToPlayerMenuView: .constant(false))
            .previewInterfaceOrientation(.landscapeRight)
    }
}
