//
//  GameMenuView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 25/04/23.
//

import SwiftUI

struct GameMenuView: View {
    @State var tutorialOpacity: Double = 0
    @StateObject var viewModel = GameMenuViewModel()
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("Background")
                    .resizable()
                
                GameMenuCardSelectionView()
                    .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
                
                Group {
                    Button {
                        viewModel.navigateToProfileView = true
                    } label: {
                        ProfileButtonView()
                    }
                    .position(x: 50, y: 50)
                    .navigationDestination(isPresented: $viewModel.navigateToProfileView) {
                        ProfileView()
                            .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
                    }
                    
                    Button {
                        audioPlayer.stop()
                    } label: {
                        SoundButtonView()
                    }
                    .position(x: 800, y: 50)
                    
                    Button {
                        tutorialOpacity = 1
                    } label: {
                        TutorialButtonView()
                    }
                    .position(x: 800, y: 110)
                    
                }
                .foregroundColor(.white)
                .navigationBarBackButtonHidden(true)
                TutorialMenuView(tutorialOpacity: $tutorialOpacity).position(x: 430, y: 175)
                    .opacity(tutorialOpacity)
            }
            .ignoresSafeArea()
        }
    }
}

struct GameMenuView_Previews: PreviewProvider {
    static var previews: some View {
        GameMenuView()
            .previewInterfaceOrientation(.landscapeRight)
    }
}
