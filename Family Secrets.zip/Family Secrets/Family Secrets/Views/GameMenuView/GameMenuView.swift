//
//  GameMenuView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 25/04/23.
//

import SwiftUI

struct GameMenuView: View {
    
    @StateObject var viewModel = GameMenuViewModel()
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("Background")
                    .resizable()
                
                GameMenuCardSelectionView()
                    .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
                
                Group {
                    Button {
                        viewModel.navigateToProfileView = true
                    } label: {
                        ProfileButtonView()
                    }
                    .position(x: 50, y: 50)
                    .navigationDestination(isPresented: $viewModel.navigateToProfileView) {
                        ProfileView()
                            .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
                    }
                    
                    Button {
                        audioPlayer.stop()
                    } label: {
                        SoundButtonView()
                    }
                    .position(x: 800, y: 50)
                    
                    Button {
                        
                    } label: {
                        TutorialButtonView()
                    }
                    .position(x: 800, y: 110)
                    
                }
                .foregroundColor(.white)
                .navigationBarBackButtonHidden(true)
            }
            .ignoresSafeArea()
        }
    }
}

struct GameMenuView_Previews: PreviewProvider {
    static var previews: some View {
        GameMenuView()
            .previewInterfaceOrientation(.landscapeRight)
    }
}
