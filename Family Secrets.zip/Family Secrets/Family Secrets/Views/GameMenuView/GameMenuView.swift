//
//  GameMenuView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 25/04/23.
//

import SwiftUI

struct GameMenuView: View {
    
    @StateObject var viewModel = GameMenuViewModel()
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color("DarkBlue")
                
                GameMenuCardSelectionView()
                    .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
                
                Group {
                    Button {
                        viewModel.navigateToProfileView = true
                    } label: {
                        Image(systemName: "person.fill")
                            .font(.system(size: 20))
                            .background(
                                Circle()
                                    .fill(.black)
                                    .frame(width: 40, height: 40)
                                    .opacity(0.2)
                            )
                    }
                    .position(x: 50, y: 50)
                    .navigationDestination(isPresented: $viewModel.navigateToProfileView) {
                        ProfileView()
                            .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
                    }
                    
                    Button {
                        
                    } label: {
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 20))
                            .background(
                                Circle()
                                    .fill(.black)
                                    .frame(width: 40, height: 40)
                                    .opacity(0.2)
                            )
                    }
                    .position(x: 800, y: 50)
                    
                    Button {
                        
                    } label: {
                        Image(systemName: "questionmark")
                            .font(.system(size: 20))
                            .background(
                                Circle()
                                    .fill(.black)
                                    .frame(width: 40, height: 40)
                                    .opacity(0.2)
                            )
                    }
                    .position(x: 800, y: 100)
                    
                }
                .foregroundColor(.white)
            }
            .ignoresSafeArea()
        }
    }
}

struct GameMenuView_Previews: PreviewProvider {
    static var previews: some View {
        GameMenuView()
            .previewInterfaceOrientation(.landscapeRight)
    }
}
