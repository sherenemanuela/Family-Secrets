//
//  ProfileView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 24/04/23.
//

import SwiftUI
import CloudKit

struct ProfileView: View {
    
    @Environment(\.managedObjectContext) var managedObjectContext
    @FetchRequest(entity: Profile.entity(), sortDescriptors: []) var profile: FetchedResults<Profile>
    @ObservedObject var viewModel = ProfileViewModel()
    
    var body: some View {
        ZStack {
            Color("DarkBlue")
            
            HStack {
                Image("\(viewModel.selectedAvatar)")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .onTapGesture {
                        viewModel.togglePopover()
                    }
                    .onAppear() {
                        getAvatar()
                    }
                
                VStack (alignment: .leading) {
                    Text("Customize your profile")
                        .bold()
                    
                    TextField("\(profile.first?.username ?? "Player")", text: $viewModel.username)
                        .frame(width: 300, height: 40)
                        .background(.white)
                        .foregroundColor(.black)
                        .cornerRadius(20)
                    
                    Button("Save") {
                        saveProfile()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.yellow)
                    .foregroundColor(.black)
                }
                .padding(.leading, 20)
            }
        }
        .foregroundColor(.white)
        .ignoresSafeArea()
        .popover(isPresented: $viewModel.showPopover) {
            AvatarView(showPopover: $viewModel.showPopover, selectedAvatar: $viewModel.selectedAvatar)
        }
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView(viewModel: ProfileViewModel())
            .previewInterfaceOrientation(.landscapeRight)
    }
}
