//
//  PlayerAvatarView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct PlayerAvatarView: View {
    
    let avatarSize: Double = 50
    let player: Player
    
    var body: some View {
        VStack {
            Image(player.avatar)
                .resizable()
                .frame(width: avatarSize, height: avatarSize)
                .cornerRadius(100)
            
            Text(player.username)
                .font(.system(size: 12))
                .foregroundColor(.white)
        }
    }
}

//struct PlayerAvatarView_Previews: PreviewProvider {
//    static var previews: some View {
//        PlayerAvatarView()
//    }
//}
