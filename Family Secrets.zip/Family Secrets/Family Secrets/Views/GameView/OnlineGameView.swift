//
//  OnlineGameView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 26/04/23.
//

import SwiftUI

struct OnlineGameView: View {
    
    @StateObject var viewModel: OnlineGameViewModel
    
    var body: some View {
        
        ZStack {
            Color("DarkBlue")
            
            VStack {
                Text("id \(viewModel.players[0].cardDeck[0].filename)")
                Text("id \(viewModel.players[0].cardDeck[1].filename)")
                Text("id \(viewModel.players[0].cardDeck[2].filename)")
                Text("id \(viewModel.players[0].cardDeck[3].filename)")
                Text("id \(viewModel.players[0].cardDeck[4].filename)")
            }
            
        }
        .ignoresSafeArea()
    }
}

struct OnlineGameView_Previews: PreviewProvider {
    static var previews: some View {
        OnlineGameView(viewModel: OnlineGameViewModel())
            .previewInterfaceOrientation(.landscapeRight)
    }
}
