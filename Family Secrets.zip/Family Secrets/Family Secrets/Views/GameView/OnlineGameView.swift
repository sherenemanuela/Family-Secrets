//
//  OnlineGameView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 26/04/23.
//

import SwiftUI

struct OnlineGameView: View {
    
    @StateObject var viewModel: OnlineGameViewModel
    
    var body: some View {
        
        ZStack {
            Color("DarkBlue")
            
            // Local Player
            Group {
                PlayerAvatarView()
                    .position(x: 200, y: 350)
                PlayerDeckView(deck: viewModel.players[0].cardDeck, basePositionX: 300, basePositionY: 360, playerType: "local")
            }
            
            
            // Other Players - left, up, right
            if viewModel.playerCount >= 2 {
                Group {
                    PlayerDeckView(deck: viewModel.players[0].cardDeck, basePositionX: 400, basePositionY: 600, playerType: "other")
                        .rotationEffect(.degrees(90))

                    PlayerAvatarView()
                        .position(x: 100, y: 300)
                }
            }
            
            if viewModel.playerCount >= 3 {
                Group{
                    PlayerAvatarView()
                        .position(x: 730, y: 300)

                    PlayerDeckView(deck: viewModel.players[0].cardDeck, basePositionX: 300, basePositionY: 600, playerType: "other")
                        .rotationEffect(.degrees(-90))
                }
            }
            
            if viewModel.playerCount == 4 {
                Group {
                    PlayerDeckView(deck: viewModel.players[0].cardDeck, basePositionX: 270, basePositionY: 350, playerType: "other")
                        .rotationEffect(.degrees(180))

                    PlayerAvatarView()
                        .position(x: 650, y: 50)
                }
            }
            
            // main deck
            GameStackView(cardStack: viewModel.players[0].cardDeck, type: "AvailableCard")
            
            GameStackView(cardStack: viewModel.players[0].cardDeck, type: "PlayedCard")
                .offset(CGSize(width: 0, height: -20))
        }
        .ignoresSafeArea()
    }
}

struct OnlineGameView_Previews: PreviewProvider {
    static var previews: some View {
        OnlineGameView(viewModel: OnlineGameViewModel())
            .previewInterfaceOrientation(.landscapeRight)
    }
}
