//
//  OnlineGameView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 26/04/23.
//

import SwiftUI

struct OnlineGameView: View {
    
    @StateObject var viewModel: OnlineGameViewModel
    
    var body: some View {
        
        NavigationStack {
            ZStack {
                Color("DarkBlue")
                
                if viewModel.playerCount >= 2 && viewModel.players.count > 1 {
                    Group {
                        PlayerDeckView(basePositionX: 400, basePositionY: 600, gameViewModel: viewModel, playerNo: 1)
                            .rotationEffect(.degrees(90))
                        
                        PlayerAvatarView(player: viewModel.players[1])
                            .position(x: 100, y: 300)
                    }
                }
                
                if viewModel.playerCount >= 3 && viewModel.players.count > 2 {
                    Group{
                        PlayerAvatarView(player: viewModel.players[2])
                            .position(x: 730, y: 300)
                        
                        PlayerDeckView(basePositionX: 300, basePositionY: 600, gameViewModel:  viewModel,playerNo: 2)
                            .rotationEffect(.degrees(-90))
                    }
                }
                
                if viewModel.playerCount == 4 && viewModel.players.count > 3 {
                    Group {
                        PlayerDeckView(basePositionX: 270, basePositionY: 350, gameViewModel: viewModel, playerNo: 3)
                            .rotationEffect(.degrees(180))
                        
                        PlayerAvatarView(player: viewModel.players[3])
                            .position(x: 650, y: 50)
                    }
                }
                
                // main deck
                GameStackView(gameViewModel: viewModel, type: "AvailableCard")
                
                GameStackView(gameViewModel: viewModel, type: "PlayedCard")
                    .offset(CGSize(width: 0, height: -20))
                
                // Local Player
                Group {
                    PlayerAvatarView(player: viewModel.players[0])
                        .position(x: 200, y: 350)
                    
                    PlayerDeckView(basePositionX: 300, basePositionY: 360, gameViewModel: viewModel, playerNo: 0)
                }
            }
            .ignoresSafeArea()
            .navigationDestination(isPresented: $viewModel.winnerIsDetermined) {
                WinnerView(player: viewModel.GetWinner())
            }
        }
    }
}
