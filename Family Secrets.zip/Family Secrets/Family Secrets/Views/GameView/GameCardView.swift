//
//  GameView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct GameCardView: View {
    
    @StateObject var viewModel: GameCardViewModel
    
    var body: some View {
        Rectangle()
            .frame(width: viewModel.width, height: viewModel.height)
            .cornerRadius(5)
            .border(.white)
            .offset(viewModel.offset)
            .onTapGesture {
                viewModel.tapped()
            }
    }
}

struct GameCardView_Previews: PreviewProvider {
    static var previews: some View {
        GameCardView(viewModel: GameCardViewModel(offset: CGSize(width: 100, height: 0)))
            .previewInterfaceOrientation(.landscapeRight)
    }
}
