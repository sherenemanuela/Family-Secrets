//
//  WinnerView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 01/05/23.
//

import SwiftUI

struct WinnerView: View {
    
    let player: Player
    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct WinnerView_Previews: PreviewProvider {
    static var previews: some View {
        WinnerView(player: Player(id: UUID().uuidString))
    }
}
