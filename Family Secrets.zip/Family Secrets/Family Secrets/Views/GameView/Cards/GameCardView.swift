//
//  GameCardStackView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct GameCardView: View {
    
    let width: Double = 80
    let height: Double = 120
    @State var positionX: CGFloat
    @State var positionY: CGFloat
    @State var initPositionX: CGFloat = 0
    @State var initPositionY: CGFloat = 0
    @State var rotation: Double = 0
    @ObservedObject var gameViewModel: OnlineGameViewModel
    
    var body: some View {
        Image("CardBack")
            .resizable()
            .frame(width: width, height: height)
            .rotationEffect(.degrees(rotation))
            .position(x: positionX, y: positionY)
            .onAppear() {
                getRandomDegree()
            }
            .onTapGesture {
                gameViewModel.players[0].cardDeck.append(gameViewModel.gameDeck[0])
                gameViewModel.RefreshDeck()
            }
    }
    
    func getRandomDegree() {
        rotation = Double.random(in: 42 ... 48) * -1
    }
}
