//
//  GameCardStackView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct GameCardView: View {
    
    let type: String
    let width: Double = 80
    let height: Double = 120
    let card: GameCard
    @State var positionX: CGFloat
    @State var positionY: CGFloat
    @State var initPositionX: CGFloat = 0
    @State var initPositionY: CGFloat = 0
    @State var rotation: Double = 0
    
    var body: some View {
        Image(getCardName())
            .resizable()
            .frame(width: width, height: height)
            .rotationEffect(.degrees(rotation))
            .position(x: positionX, y: positionY)
            .onAppear() {
                initPositionX = positionX
                initPositionY = positionY
                getRandomDegree()
            }
        
        // ini buat yang ambil kartu dari available card stack
//            .gesture(
//                DragGesture()
//                    .onChanged ({ value in
//                        positionX = value.location.x
//                        positionY = value.location.y
//                        rotation = 0
//                    })
//                    .onEnded({ _ in
//                        if type == "AvailableCard" {
//                            if positionX < 190 || positionX > 210 || positionY < 90 || positionY > 110 {
//                                positionX = initPositionX
//                                positionY = initPositionY
//                                return
//                            } else {
//                                initPositionX = positionX
//                                initPositionY = positionY
//                            }
//                        }
//                    })
//            )
    }
    
    func getCardName() -> String {
        if type == "AvailableCard" {
            return "CardBack"
        }
        return card.filename
    }
    
    func getRandomDegree() {
        if type == "AvailableCard" {
            rotation = Double.random(in: 42 ... 48) * -1
        }
        rotation = Double.random(in: -5 ... 5)
    }
}
