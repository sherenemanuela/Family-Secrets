//
//  PlayerDeckView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct PlayerDeckView: View {
    
    @State var basePositionX: CGFloat
    @State var basePositionY: CGFloat
    @ObservedObject var gameViewModel: OnlineGameViewModel
    let playerNo: Int
    
    var body: some View {
        ZStack{
            if gameViewModel.players[playerNo].cardDeck.count > 0 {
                ForEach(gameViewModel.players[playerNo].cardDeck.indices, id: \.self) { i in
                    if gameViewModel.players[playerNo].cardDeck[i].isInPlayerDeck {
                        if playerNo == 0 {
                            PlayerCardView(cardNo: i, positionX: getPositionX(cardNo: i), positionY: basePositionY, zIndex: Double(i), card: gameViewModel.players[0].cardDeck[i], gameViewModel: gameViewModel)
                        } else {
                            OtherPlayerCardView(card: gameViewModel.players[playerNo].cardDeck[i], positionX: getPositionX(cardNo: i), positionY: basePositionY)
                        }
                    }
                }
            }
        }
    }
    
    func getPositionX(cardNo: Int) -> CGFloat {
        return 30 * CGFloat(cardNo) + basePositionX
    }
}
