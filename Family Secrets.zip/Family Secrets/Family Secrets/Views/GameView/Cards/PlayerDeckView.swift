//
//  PlayerDeckView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct PlayerDeckView: View {
    
    @State var basePositionX: CGFloat
    @State var basePositionY: CGFloat
    @ObservedObject var gameViewModel: OnlineGameViewModel
    let playerNo: Int
    
    var body: some View {
        ZStack{
            ForEach(gameViewModel.players[0].cardDeck.indices, id: \.self) { i in
                if playerNo == 1 && gameViewModel.players[0].cardDeck[i].isInPlayerDeck {
                    PlayerCardView(cardNo: i, positionX: getPositionX(cardNo: i), positionY: basePositionY, zIndex: Double(i), gameViewModel: gameViewModel)
                } else {
                    OtherPlayerCardView(card: gameViewModel.players[0].cardDeck[i], positionX: getPositionX(cardNo: i), positionY: basePositionY)
                }
            }
        }
    }
    
    func getPositionX(cardNo: Int) -> CGFloat {
        return 30 * CGFloat(cardNo) + basePositionX
    }
}
