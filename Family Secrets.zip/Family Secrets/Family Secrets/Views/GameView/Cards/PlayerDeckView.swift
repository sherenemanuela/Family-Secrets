//
//  PlayerDeckView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct PlayerDeckView: View {
    
    @State var deck: Array<GameCard>
    @State var baseOffset: CGFloat = 30
    @State var basePositionX: CGFloat
    @State var basePositionY: CGFloat
    let playerType: String
    
    var body: some View {
        ZStack{
            ForEach(0 ..< deck.count) { i in
                if playerType == "local"{
                    PlayerCardView(card: deck[i], positionX: getPositionX(cardNo: i), positionY: basePositionY)
                } else {
                    OtherPlayerCardView(card: deck[i], positionX: getPositionX(cardNo: i), positionY: basePositionY)
                }
            }
        }
    }
    
    func getPositionX(cardNo: Int) -> CGFloat {
        return baseOffset * CGFloat(cardNo) + basePositionX
    }
}
