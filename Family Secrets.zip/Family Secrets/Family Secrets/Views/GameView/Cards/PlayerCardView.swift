//
//  GameView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct PlayerCardView: View {
    
    let width: Double = 100
    let height: Double = 140
    @State var card: GameCard
    @State var positionX: CGFloat
    @State var positionY: CGFloat
    @State var prevPositionX: CGFloat = 0
    @State var prevPositionY: CGFloat = 0
    
    var body: some View {
        Image("\(card.filename)")
            .resizable()
            .frame(width: width, height: height)
            .position(x: positionX, y: positionY)
            .onAppear() {
                prevPositionX = positionX
                prevPositionY = positionY
            }
            .gesture(
                DragGesture()
                    .onChanged ({ value in
                        positionX = value.location.x
                        positionY = value.location.y
                    })
                    .onEnded({ _ in
                        if positionX > 350 && positionX < 450 && positionY > 150 && positionY < 250 {
                            positionX = 400
                            positionY = 200
                            return
                        } else {
                            positionX =  prevPositionX
                            positionY = prevPositionY
                        }
                    })
            )
    }
}
