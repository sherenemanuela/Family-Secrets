//
//  GameView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct PlayerCardView: View {
    
    @State var width: Double = 100
    @State var height: Double = 140
    @State var cardNo: Int
    @State var positionX: CGFloat
    @State var positionY: CGFloat
    @State var prevPositionX: CGFloat = 0
    @State var prevPositionY: CGFloat = 0
    @State var zIndex: Double
    @State var showingDetailView: Bool = false
    @State var overlayOpacity: Double = 0
    @State var card: GameCard
    @ObservedObject var gameViewModel: OnlineGameViewModel
    
    var body: some View {
        if cardNo < gameViewModel.players[0].cardDeck.count {
            ZStack {
                Rectangle()
                    .background(.gray)
                    .opacity(overlayOpacity)
                Image("\(gameViewModel.players[0].cardDeck[cardNo].filename)")
                    .resizable()
                    .frame(width: width, height: height)
                    .position(x: positionX, y: positionY)
                    .onAppear() {
                        setInitialPosition()
                    }
                    .gesture(
                        DragGesture()
                            .onChanged ({ value in
                                if gameViewModel.currentPlayer == gameViewModel.players[0].id {
                                    positionX = value.location.x
                                    positionY = value.location.y
                                }
                            })
                            .onEnded({ _ in
                                if gameViewModel.currentPlayer == gameViewModel.players[0].id {
                                    if positionX > 350 && positionX < 450 && positionY > 150 && positionY < 250 && gameViewModel.CardChosenisValidAnswer(index: cardNo) {
                                        updatePlayedCardData()
                                        return
                                    } else {
                                        positionX =  prevPositionX
                                        positionY = prevPositionY
                                    }
                                }
                            })
                    )
                    .onTapGesture {
                        if showingDetailView {
                            width = 100
                            height = 140
                            zIndex = Double(cardNo)
                            resetInitialPosition()
                            overlayOpacity = 0
                            showingDetailView = false
                        } else {
                            positionX = 400
                            positionY = 200
                            width = 200
                            height = 280
                            zIndex = 100
                            overlayOpacity = 0.5
                            showingDetailView = true
                        }
                    }
            }
            .zIndex(zIndex)
        }
    }
    
    func setInitialPosition() {
        prevPositionX = positionX
        prevPositionY = positionY
    }
    
    func resetInitialPosition() {
        positionX = prevPositionX
        positionY = prevPositionY
    }
    
    func updatePlayedCardData() {
        let card = gameViewModel.players[0].cardDeck[cardNo]
        
        resetInitialPosition()
        gameViewModel.AddToPlayedDeck(index: cardNo)
        gameViewModel.sendData(data: gameViewModel.GetInitialPlayedCardData(), mode: .reliable)
        gameViewModel.sendData(
            data: gameViewModel.GetPlayerPlayedCardData(id: gameViewModel.players[0].id, index: cardNo),
            mode: .reliable)
        
        if card.prompt != "free" {
            if card.type == "special" {
                if gameViewModel.players[0].id == gameViewModel.ownerId {
                    var nextPlayer = gameViewModel.players[1]
                    
                    for _ in 0 ..< Int(card.prompt)! {
                        print("NAMBAH KARTU")
                        gameViewModel.gameDeck.last?.isInPlayerDeck = true
                        
                        let card = gameViewModel.gameDeck.popLast()
                        nextPlayer.cardDeck.append(card!)
                        gameViewModel.sendData(data: gameViewModel.GetPlayerDeckData(id: nextPlayer.id, card: card!), mode: .reliable)
                        gameViewModel.sendData(data: gameViewModel.GetStringData(label: "popGameDeck", message: ""), mode: .reliable)
                        gameViewModel.ReshuffleCard()
                    }
                } else {
                    gameViewModel.sendData(data: gameViewModel.GetStringData(label: "specialToOwner", message: card.prompt), mode: .reliable)
                }
            }
            
            if !gameViewModel.winnerIsFound() {
                gameViewModel.UpdateCurrentPlayer()
            }
        }
    }
}
