//
//  GameView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct PlayerCardView: View {
    
    @State var width: Double = 100
    @State var height: Double = 140
    @State var cardNo: Int
    @State var positionX: CGFloat
    @State var positionY: CGFloat
    @State var prevPositionX: CGFloat = 0
    @State var prevPositionY: CGFloat = 0
    @State var zIndex: Double
    @State var showingDetailView: Bool = false
    @State var overlayOpacity: Double = 0
    @ObservedObject var gameViewModel: OnlineGameViewModel
    
    var body: some View {
        if cardNo < gameViewModel.players[0].cardDeck.count {
            ZStack {
                Rectangle()
                    .background(.gray)
                    .opacity(overlayOpacity)
                Image("\(gameViewModel.players[0].cardDeck[cardNo].filename)")
                    .resizable()
                    .frame(width: width, height: height)
                    .position(x: positionX, y: positionY)
                    .onAppear() {
                        setInitialPosition()
                    }
                    .gesture(
                        DragGesture()
                            .onChanged ({ value in
                                positionX = value.location.x
                                positionY = value.location.y
                            })
                            .onEnded({ _ in
                                if positionX > 350 && positionX < 450 && positionY > 150 && positionY < 250 && gameViewModel.CardChosenisValidAnswer(index: cardNo) {
                                    resetInitialPosition()
                                    gameViewModel.AddToPlayedDeck(index: cardNo)
                                    return
                                } else {
                                    positionX =  prevPositionX
                                    positionY = prevPositionY
                                }
                            })
                    )
                    .onTapGesture {
                        if showingDetailView {
                            width = 100
                            height = 140
                            zIndex = Double(cardNo)
                            resetInitialPosition()
                            overlayOpacity = 0
                            showingDetailView = false
                        } else {
                            positionX = 400
                            positionY = 200
                            width = 200
                            height = 280
                            zIndex = 100
                            overlayOpacity = 0.5
                            showingDetailView = true
                        }
                    }
            }
            .zIndex(zIndex)
        }
    }
    
    func setInitialPosition() {
        prevPositionX = positionX
        prevPositionY = positionY
    }
    
    func resetInitialPosition() {
        positionX = prevPositionX
        positionY = prevPositionY
    }
}







// might be used tp error jd blkgan

//                .onTapGesture {
//                    gameViewModel.players[0].removeCard(index: cardNo)
//                    gameViewModel.RefreshDeck()
//                }
//                .onChange(of: removedCardNo) { value in
//                    if cardNo > removedCardNo {
//                        if cardNo == removedCardNo + 1 {
//                            print("Mulai remove pas removedCardNo brubah")
//                            print("CardNo: \(cardNo)")
//                            print("jumlah kartu dideck abis remove : \(gameViewModel.players[0].cardDeck.count)")
//                            removedCardNo = 100
//                        }
//                        cardNo -= 1
//                        positionX -= 30
//                        setInitialPosition()
//                    }
//                }
