//
//  CardElementView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct CardElementView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CardElementView_Previews: PreviewProvider {
    static var previews: some View {
        CardElementView()
    }
}
