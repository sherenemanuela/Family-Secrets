//
//  PlayerDeckScrollView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 04/05/23.
//

import SwiftUI

struct PlayerDeckScrollView: View {
    
    @ObservedObject var gameViewModel: OnlineGameViewModel
    @Binding var deckOpacity: Double
    @Binding var overlayOpacity: Double
    
    var body: some View {
        ZStack {
            Rectangle()
                .background(.gray)
                .opacity(overlayOpacity)
                .frame(width: .infinity, height: .infinity)
                .onTapGesture {
                    deckOpacity = 0
                    overlayOpacity = 0
                }
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    ForEach(gameViewModel.players[0].cardDeck.indices, id: \.self) { i in
                        if gameViewModel.players[0].cardDeck[i].isInPlayerDeck {
                            LocalPlayerCardView(width: 200, height: 300, cardNo: i, card: gameViewModel.players[0].cardDeck[i], gameViewModel: gameViewModel, deckOpacity: $deckOpacity, overlayOpacity: $overlayOpacity)
                        }
                    }
                }
            }
            .frame(width: .infinity, height: 300)
        }
    }
}
