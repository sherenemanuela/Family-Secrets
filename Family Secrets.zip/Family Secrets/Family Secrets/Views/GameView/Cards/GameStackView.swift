//
//  GameDeckView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct GameStackView: View {
    @State var cardStack: Array<GameCard>
    let type: String
    var body: some View {
        ZStack {
            
            if type == "AvailableCard" {
                ForEach(0 ..< cardStack.count) { i in
                    GameCardView(type: type, card: cardStack[i], positionX: 200, positionY: 100)
                }
            } else {
                ForEach(0 ..< cardStack.count) { i in
                    GameCardView(type: type, card: cardStack[i], positionX: 400, positionY: 200)
                }
            }
            
        }
    }
    
    func addToCardStack(newCard: GameCard) {
        cardStack.append(newCard)
    }
}
