//
//  MatchmakingView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct MatchmakingView: View {
    
    @Environment(\.managedObjectContext) var managedObjectContext
    @FetchRequest(entity: Game.entity(), sortDescriptors: []) var game: FetchedResults<Game>
    @StateObject var viewModel = OnlineGameViewModel()
    
    var body: some View {
        NavigationStack {
            Color("DarkBlue")
                .ignoresSafeArea()
                .onAppear() {
                    viewModel.playerCount = Int(game.first!.playerCount)
                    viewModel.StartMatchmaking()
                }
                .navigationDestination(isPresented: $viewModel.matchFound) {
                    OnlineGameView(viewModel: viewModel)
                }
        }
    }
}
