//
//  MatchmakingView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 27/04/23.
//

import SwiftUI

struct MatchmakingView: View {
    
    @Environment(\.managedObjectContext) var managedObjectContext
    @FetchRequest(entity: Game.entity(), sortDescriptors: []) var game: FetchedResults<Game>
    @StateObject var viewModel = OnlineGameViewModel()
    
    var body: some View {
        NavigationStack {
            Color("DarkBlue")
                .ignoresSafeArea()
                .onAppear() {
//                    viewModel.playerCount = Int(game.first!.playerCount)
//                    viewModel.StartMatchmaking()
                    viewModel.InitGameRoom()
                    viewModel.matchFound = true
                }
                .navigationDestination(isPresented: $viewModel.matchFound) {
                    OnlineGameView(viewModel: viewModel)
                }
        }
    }
}

//struct MatchmakingView_Previews: PreviewProvider {
//    static var previews: some View {
//        MatchmakingView()
//            .previewInterfaceOrientation(.landscapeRight)
//    }
//}
