//
//  OnlineGameView.swift
//  Family Secrets
//
//  Created by Sheren Emanuela on 26/04/23.
//

import SwiftUI

struct OnlineGameView: View {
    
    @StateObject var viewModel = OnlineGameViewModel()
    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
            .onAppear() {
                GameCenterHelper().StartMatchmaking()
            }
    }
}

struct OnlineGameView_Previews: PreviewProvider {
    static var previews: some View {
        OnlineGameView()
    }
}
